module Api
  module V1
    class EventsController < ApplicationController
      skip_before_action :verify_authenticity_token
      before_action :authenticate_api_key

      def create
        event = Event.new(event_params)

        if event.save
          render json: {
            status: "ok",
            id: event.id,
            message: "Event saved"
          }, status: :created
        else
          render json: {
            status: "error",
            errors: event.errors.full_messages
          }, status: :unprocessable_entity
        end
      end

      private

      def authenticate_api_key
        api_key = request.headers["X-API-Key"]
        expected_key = ENV.fetch("SIEM_API_KEY", "dev-secret-key-12345")

        unless api_key == expected_key
          render json: { status: "error", message: "Unauthorized" }, status: :unauthorized
        end
      end

      def event_params
        params.require(:event).permit(:level, :message, :source, :user_id)
      end
    end
  end
end