Rails.application.routes.draw do
  root 'events#index'

  get 'events/stats', to: 'events#stats'

  resources :events, only: [:index, :show]
end
