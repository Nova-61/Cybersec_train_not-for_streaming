class EventsController < ApplicationController
  def index
    @events = Event.order(created_at: :desc)

    if params[:level].present?
      @events = @events.where(level: params[:level])
    end
  end

  def show
    @event = Event.find(params[:id])
  end

  def stats
    @total = Event.count
    @info = Event.where(level: "INFO").count
    @warning = Event.where(level: "WARNING").count
    @error = Event.where(level: "ERROR").count
  end
end
